// MenuModel.java
package com.example.eccpizza;

public class MenuModel {
    private String productName;
    private String imageUrl;
    private double price;

    public MenuModel(String productName, String imageUrl, double price) {
        this.productName = productName;
        this.imageUrl = imageUrl;
        this.price = price;
    }

    public String getProductName() {
        return productName;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public double getPrice() {
        return price;
    }
}
