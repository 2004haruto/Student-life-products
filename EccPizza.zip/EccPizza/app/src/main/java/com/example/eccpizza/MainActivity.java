package com.example.eccpizza;

import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private MenuAdapter menuAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.rv_adventurer_list);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // AsyncTaskを使って非同期でデータを取得
        new FetchMenuTask().execute("http://click.ecc.ac.jp/ecc/yishida/pizzaDB.php");

        // 商品詳細表示のためのレイアウト
        CardView cardView = findViewById(R.id.RecyclerView);
        ImageView productImage = findViewById(R.id.iv_productImage);
        TextView productName = findViewById(R.id.tv_productName);
        TextView price = findViewById(R.id.tv_price);

        // 仮の商品情報をセット
        String sampleProductName = "Delicious Pizza";
        String samplePrice = "￥1000";
        int sampleImageResource = R.drawable.no_image;

        productName.setText(sampleProductName);
        price.setText(samplePrice);
        productImage.setImageResource(sampleImageResource);

        // スクロールができるようにする
        recyclerView.setNestedScrollingEnabled(false);
    }

    private class FetchMenuTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... params) {
            String apiUrl = params[0];
            try {
                URL url = new URL(apiUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                InputStream inputStream = connection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));

                StringBuilder result = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    result.append(line);
                }

                bufferedReader.close();
                inputStream.close();
                connection.disconnect();

                return result.toString();
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            if (result != null) {
                // 取得したデータを解析してリストに表示
                displayMenu(result);
            } else {
                Toast.makeText(MainActivity.this, "データの取得に失敗しました", Toast.LENGTH_SHORT).show();
            }
        }

        private void displayMenu(String result) {
            try {
                JSONArray jsonArray = new JSONArray(result);
                ArrayList<MenuModel> menuList = new ArrayList<>();

                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject menuObject = jsonArray.getJSONObject(i);

                    String productName = menuObject.getString("pname");
                    String imageUrl = menuObject.getString("image_url");
                    double price = menuObject.getDouble("price");

                    MenuModel menu = new MenuModel(productName, imageUrl, price);
                    menuList.add(menu);
                }

                // MenuAdapterを使ってRecyclerViewにデータをセット
                menuAdapter = new MenuAdapter(menuList);
                recyclerView.setAdapter(menuAdapter);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        //Retrofit setup
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://click.ecc.ac.jp/ecc/yishida/")
                .addConverterFactory(GsonconverterFactory.create())
                .build();


    }
}

