package com.example.eccpizza;

import java.util.List;

public interface ApiService {
    @GET("pizzaDB.php")
    Call<List<Pizza>> getPizzas();
}
