package com.example.weatherapi;// MainActivity.java

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    private static final List<String> cities = Arrays.asList("Tokyo", "Osaka", "Kyoto", "Hiroshima",
            "Fukuoka", "Hokkaido", "Okinawa", "Aomori", "Nagano", "Tottori", "Nagoya");

    private List<OpenWeatherResponse> weatherList = new ArrayList<>();
    private WeatherAdapter adapter;
    private RecyclerView recyclerView;

    private Retrofit retrofit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.rv_weatherlist);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        retrofit = new Retrofit.Builder()
                .baseUrl("https://api.openweathermap.org/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        // fetchWeatherData メソッドを都市リストの各要素に対して呼び出す
        for (String city : cities) {
            fetchWeatherData(city);
        }
    }

    private void fetchWeatherData(String city) {
        WeatherApi api = retrofit.create(WeatherApi.class);
        Call<OpenWeatherResponse> call = api.fetchWeather(city, "ja", "5b15c2502be34f6c88fffe80170ab019");

        call.enqueue(new Callback<OpenWeatherResponse>() {
            @Override
            public void onResponse(Call<OpenWeatherResponse> call, Response<OpenWeatherResponse> response) {
                if (response.isSuccessful()) {
                    OpenWeatherResponse weatherData = response.body();
                    if (weatherData != null) {
                        weatherList.add(weatherData);
                        setUpRecyclerView();
                    }
                } else {
                    Toast.makeText(MainActivity.this, "Error fetching data for city: " + city, Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<OpenWeatherResponse> call, Throwable t) {
                Toast.makeText(MainActivity.this, "Failed to fetch data for city: " + city, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void setUpRecyclerView() {
        if (adapter == null) {
            adapter = new WeatherAdapter(weatherList);
            recyclerView.setAdapter(adapter);
        } else {
            adapter.notifyDataSetChanged();
        }
    }
}
