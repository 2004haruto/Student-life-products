package com.example.weatherapi;// WeatherAdapter.java

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class WeatherAdapter extends RecyclerView.Adapter<WeatherAdapter.ViewHolder> {

    private List<OpenWeatherResponse> weatherList;

    public WeatherAdapter(List<OpenWeatherResponse> weatherList) {
        this.weatherList = weatherList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.weather_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        OpenWeatherResponse weatherData = weatherList.get(position);

        String cityName = weatherData.getName();
        String weatherDescription = weatherData.getWeather().get(0).getDescription();
        double temperature = weatherData.getMain().getTemp() - 273.15; // Convert to Celsius

        holder.cityNameTextView.setText(cityName);
        holder.weatherTextView.setText(weatherDescription);
        holder.temperatureTextView.setText(String.format("%.1f ℃", temperature));
    }

    @Override
    public int getItemCount() {
        return weatherList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView cityNameTextView;
        public TextView weatherTextView;
        public TextView temperatureTextView;

        public ViewHolder(View itemView) {
            super(itemView);
            cityNameTextView = itemView.findViewById(R.id.tv_city_name);
            weatherTextView = itemView.findViewById(R.id.tv_weather_description);
            temperatureTextView = itemView.findViewById(R.id.tv_temperature);
        }
    }
}
