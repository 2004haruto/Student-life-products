/**
 * OpenWeatherResponseクラスは、OpenWeatherMap　APIから取得した天気情報のレスポンスを表すクラスです。
 */

package com.example.weatherapi;

import java.util.List;

public class OpenWeatherResponse {
    //都市の名前を表す変数。例:"Tokyo"や"Kyoto"など。
    private String name;
    //天気に関する詳細情報(例:晴れ、曇り)を格納するリスト。
    //APIのレスポンスには複数の天気情報が含まれることがあるため、リストとして管理します。
    private List<Weather> weather;
    //天気に関する主要な情報(特に気温)を表すクラスのインスタンスを参照する変数。
    private Main main;
    //name変数の値を取得するためのゲッターメソッド。
    public String getName() {return name;}
    //weatherリストの値を取得するためのゲッターメソッド。
    public List<Weather> getWeather() {return weather;}
    //main変数の値を取得するためのゲッターメソッド。
    public Main getMain() {return main;}

    /**
     * Mainクラスは、天気の主要な情報(特に気温)を表すクラスです。
     */
    public static class Main{
        //現在の気温を保存する変数。単位はケルビン。
        private double temp;
        //temp変数の値を取得するためのゲッターメソッド。
        public double getTemp() {return temp;}
    }
    /**
     * Weatherクラスは、天気の詳細情報(例:晴れ、曇りなど)を表すクラスです。
     */
    public static class Weather{
        //天気の詳細な説明を保存する変数。例:"clear sky"や"few clouds"など。
        private String description;
        //description変数の値を取得するためのゲッターメソッド。
        public String getDescription() {return description;}
    }
}
