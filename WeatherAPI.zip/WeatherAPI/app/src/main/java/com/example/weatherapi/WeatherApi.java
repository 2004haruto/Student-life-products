package com.example.weatherapi;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

//WeatherApiインターフェースは、天気情報を取得するためのAPIエンドポイントを定義するインターフェースです。
public interface WeatherApi {
    //@GETアノテーションは、APIのエンドポイントとHTTPのGETメソッドを指定します。
    //この場合、"data/2.5/weather"というエンドポイントで天気情報を取得します。
    @GET("data/2.5/weather")
    //fetchWeatherメソッドは、指定された都市の天気情報を取得するためのリクエストを定義するメソッドです。
    Call<OpenWeatherResponse> fetchWeather(
            //@Queryアノテーションは、APIリクエストのクエリパラメータを指定します。
            //"q"は都市名を指定するクエリパラメータ。"lang"はレスポンスの言語を指定するクエリパラメータ。"appid"はAPIキーを指定するクエリパラメータをそれぞれ表します。
            @Query("q") String city, //都市名
            @Query("lang") String language, //レスポンスの言語
            @Query("appid") String apiKey //APIキー

    );
}
