package jp.ac.ecc.tyoshihara.calculatorapplication

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity(), View.OnClickListener { // OnClickListenerインターフェースを実装

    // プログラムで使用する部品の変数宣言
    lateinit var answerLabel: TextView
    lateinit var operatorLabel: TextView
    lateinit var leftNumEdit: EditText
    lateinit var rightNumEdit: EditText
    lateinit var addButton: Button
    lateinit var subButton: Button
    lateinit var mulButton: Button
    lateinit var divButton: Button
    lateinit var calcButton: Button

    // 演算子管理変数
    var operator = "＋";

    // 画面が生成されるタイミングで実行されるメソッド
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        // XMLファイルのレイアウトを設定
        setContentView(R.layout.activity_calc)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // XMLのIDと変数の紐づけ処理
        answerLabel = findViewById(R.id.answerLabel)
        operatorLabel = findViewById(R.id.operatorLabel)
        leftNumEdit = findViewById(R.id.leftNumEdit)
        rightNumEdit = findViewById(R.id.rightNumEdit)

        addButton = findViewById(R.id.addButton)
        subButton = findViewById(R.id.subButton)
        mulButton = findViewById(R.id.mulButton)
        divButton = findViewById(R.id.divButton)
        calcButton = findViewById(R.id.calcButton)

        // OnClickListenerに自身のリスナーを設定
        addButton.setOnClickListener(this)
        subButton.setOnClickListener(this)
        mulButton.setOnClickListener(this)
        divButton.setOnClickListener(this)

        // calcButtonのクリックイベント
        calcButton.setOnClickListener {

            // 未入力チェック
            if (leftNumEdit.text.isEmpty() || rightNumEdit.text.isEmpty()) {
                Toast.makeText(applicationContext, "数値を入力してください", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // ゼロ除算チェック
            val leftNum = leftNumEdit.text.toString().toInt()
            val rightNum = rightNumEdit.text.toString().toInt()

            if (operator == "÷" && rightNum == 0) {
                Toast.makeText(applicationContext, "0で除算は出来ません", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // 演算子により計算ロジックを分岐
            val ans = when (operator) {
                "＋" -> leftNum + rightNum
                "－" -> leftNum - rightNum
                "×" -> leftNum * rightNum
                "÷" -> leftNum / rightNum
                else -> 0
            }

            // 計算結果を表示
            answerLabel.text = ans.toString()
            leftNumEdit.setText(ans.toString())
            rightNumEdit.text.clear()
        }
    }

    // OnClickListenerで受け付けたクリックイベントメソッド
    override fun onClick(v: View?) {
        v?.let {
            operator = when (it.id) {
                //R.id.addButton -> null //ここを修正
                R.id.addButton -> "＋"
                R.id.subButton -> "－"
                R.id.mulButton -> "×"
                R.id.divButton -> "÷"
                else -> operator
            }
            // 演算子の表示を切替える
            operatorLabel.text = operator
        }
    }
}
