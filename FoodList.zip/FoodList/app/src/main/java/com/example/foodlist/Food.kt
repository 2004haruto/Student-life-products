package com.example.foodlist

data class Food(
    val imgResID: Int, // 画像のリソースID
    val name: String,  // 食べ物の名前
    val category: String  // 食べ物のカテゴリ（例：果物、お菓子など）
)