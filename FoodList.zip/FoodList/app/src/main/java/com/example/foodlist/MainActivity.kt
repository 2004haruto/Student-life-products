package com.example.foodlist

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.foodlist.Food
import com.example.foodlist.FoodAdapter
import com.example.foodlist.R

class MainActivity : AppCompatActivity() {

    lateinit var srv : RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        //レイアウトとプログラムの紐づけ
        srv = findViewById(R.id.sampleRecyclerView)
        //レイアウトを設定する
        srv.layoutManager = LinearLayoutManager(applicationContext)

        // デモ用の食べ物データを作成します。
        // このデータはRecyclerViewに表示されるものです。
        val foods = listOf(
            Food(R.drawable.apple, "apple", "果物"),
            Food(R.drawable.banana, "banana", "果物"),
            Food(R.drawable.cherry, "cherry", "果物"),
            Food(R.drawable.donut, "donut", "お菓子"),
            Food(R.drawable.egg, "egg", "食材"),
            Food(R.drawable.frenchfries, "frenchfries", "料理"),
            Food(R.drawable.grape, "grape", "果物"),
            Food(R.drawable.hamburger, "hamburger", "料理"),
        )

        //RecyclerViewにAdapterをセット
        srv.adapter = FoodAdapter(foods)

    }
}