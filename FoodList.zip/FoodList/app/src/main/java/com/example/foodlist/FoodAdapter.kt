package com.example.foodlist

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class FoodAdapter(private val foods:List<Food>):RecyclerView.Adapter<FoodAdapter.ViewHolder>(){

    class ViewHolder(item: View) : RecyclerView.ViewHolder(item) {

        val foodImageView : ImageView
        val nameLabel : TextView
        val categoryLabel : TextView

        init {
            foodImageView = item.findViewById(R.id.foodImageView)
            nameLabel = item.findViewById(R.id.nameLabel)
            categoryLabel = item.findViewById(R.id.categoryLabel)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.list_row, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.foodImageView.setImageResource(foods[position].imgResID)
        holder.nameLabel.text = foods[position].name
        holder.categoryLabel.text = foods[position].category
    }

    override fun getItemCount(): Int {
        return foods.size
    }
}