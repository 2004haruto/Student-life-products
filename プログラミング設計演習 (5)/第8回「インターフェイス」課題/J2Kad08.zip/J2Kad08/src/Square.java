public class Square extends Rectangle  {
    public Square(int left, int top, int width){
        super(left,top,width,width);
    }
}