package example08;

public interface Command {
    String name ="�R�}���h";
    void btnA();
    void btnB();
    void btnX();
    void btnY();
}
