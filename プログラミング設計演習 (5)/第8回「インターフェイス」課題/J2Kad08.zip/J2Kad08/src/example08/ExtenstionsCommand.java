package example08;

public interface ExtenstionsCommand {
    void btnV();
    void btnW();
}
