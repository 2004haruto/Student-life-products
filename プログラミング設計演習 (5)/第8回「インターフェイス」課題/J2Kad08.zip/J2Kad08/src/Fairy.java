public interface Fairy {
    void intro();
    void heal();
}
