public interface IPhone {
    void call();
}
