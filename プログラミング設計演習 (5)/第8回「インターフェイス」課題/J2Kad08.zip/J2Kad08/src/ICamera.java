public interface ICamera {
    void takePicture();
    void displayImage();
}
