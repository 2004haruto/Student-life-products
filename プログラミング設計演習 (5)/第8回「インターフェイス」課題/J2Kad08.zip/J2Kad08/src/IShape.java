public interface IShape {
    void draw(Canvas c);
}