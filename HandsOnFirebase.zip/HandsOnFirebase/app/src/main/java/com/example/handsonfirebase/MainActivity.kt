package com.example.handsonfirebase

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.handsonfirebase.adapter.TodoAdapter
import com.example.handsonfirebase.dialog.TodoDialogFragment
import com.example.handsonfirebase.model.Todo
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.firebase.firestore.CollectionReference
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import java.util.Date

class MainActivity : AppCompatActivity(), TodoDialogFragment.TodoDialogListener {

    lateinit var todoRecyclerView: RecyclerView
    lateinit var createFab: FloatingActionButton

    // Firestoreのコレクション参照変数を宣言
    lateinit var todoRef: CollectionReference

    // ダミー用データ
    val dummyList = mutableListOf<Todo>(
        Todo(null, "カレー具材そろえる", 2.5F, Date()),
        Todo(null, "レンタカー受取に行く", 1F,  Date()),
        Todo(null, "キャンプ場予約する", 5F, Date())
    )

    // Firebase取得データ
    val todoList = mutableListOf<Todo>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        todoRecyclerView = findViewById(R.id.todoRecyclerView)
        createFab = findViewById(R.id.createButton)

        // Firestoreのコレクション参照をインスタンス化する
        todoRef = Firebase.firestore.collection("todos")

        // 変更検知されたら呼び出されるリスナーを実装する
        todoRef.orderBy("priority", Query.Direction.DESCENDING).addSnapshotListener { value, error ->
            value?.let{
                val todos = it.toObjects(Todo::class.java)
                todoList.clear()
                todoList.addAll(todos)
                todoRecyclerView.adapter?.let{
                    it.notifyDataSetChanged()
                }
            }
        }

        todoRecyclerView.layoutManager = LinearLayoutManager(this)
        todoRecyclerView.adapter = TodoAdapter(
            todoList,
            cardOnClick = { todo ->
                // カードをクリックされたら対象データのダイアログを表示
                val newDialog = TodoDialogFragment.newInstance(todo)
                newDialog.show(supportFragmentManager, "update")
            },
            deleteOnClick = { todo ->
                // ゴミ箱アイコンクリックでTodoデータを削除
                todoRef.document(todo.documentId!!).delete()
                Toast.makeText(applicationContext, "${todo.memo}を削除しました", Toast.LENGTH_SHORT).show()
            }
        )

        createFab.setOnClickListener {

            // 新規Todoクラスを生成してダイアログを表示
            val newDialog = TodoDialogFragment.newInstance(Todo())
            newDialog.show(supportFragmentManager, "create")

        }
    }

    // Todoダイアログの登録ボタンクリックイベント
    override fun onDialogSubmitClick(dialog: TodoDialogFragment, todo: Todo?) {

        todo?.let{ todo ->
            if(todo.documentId == null){
                // DocumentIDが存在しない場合は、新規登録
                todoRef.add(todo)
            }else{
                // DocumentIDと一致するドキュメントを上書きする
                todoRef.document(todo.documentId).set(todo)
            }
        }
        dialog.dismiss()
    }
}