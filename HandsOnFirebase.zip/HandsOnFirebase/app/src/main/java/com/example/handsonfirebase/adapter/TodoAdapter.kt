package com.example.handsonfirebase.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.RatingBar
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.example.handsonfirebase.R
import com.example.handsonfirebase.model.Todo

class TodoAdapter(
    private val todoList: List<Todo>,
    private val cardOnClick: (Todo) -> Unit,
    private val deleteOnClick: (Todo) -> Unit
): RecyclerView.Adapter<TodoAdapter.ViewHolder>() {

    class ViewHolder(item: View): RecyclerView.ViewHolder(item) {

        val memoCard: CardView
        val memoText: TextView
        val priorityRating: RatingBar
        val deleteButton: ImageView // 画像のためImageViewで処理を行う

        init {
            memoCard = item.findViewById(R.id.memoCard)
            memoText = item.findViewById(R.id.memoText)
            priorityRating = item.findViewById(R.id.priorityRating)
            deleteButton = item.findViewById(R.id.deleteButton)
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TodoAdapter.ViewHolder {
        val item = LayoutInflater.from(parent.context).inflate(R.layout.row_item, parent, false)
        return ViewHolder(item)
    }

    override fun onBindViewHolder(holder: TodoAdapter.ViewHolder, position: Int) {

        holder.memoText.text = todoList[position].memo
        holder.priorityRating.rating = todoList[position].priority

        holder.memoCard.setOnClickListener {
            cardOnClick(todoList[position])
        }
        holder.deleteButton.setOnClickListener {
            deleteOnClick(todoList[position])
        }
    }

    override fun getItemCount(): Int {
        return todoList.size
    }
}