package com.example.handsonfirebase.model

import android.os.Parcelable
import com.google.firebase.firestore.DocumentId
import kotlinx.parcelize.Parcelize
import java.util.Date

@Parcelize
data class Todo(
    @DocumentId
    val documentId: String? = null, // FirestoreのドキュメントIDを保持。新しいメモを作成する場合はnullを設定
    var memo: String = "",
    var priority: Float = 0.0F,  // メモの優先度。数字が大きいほど優先度が高い。設定値は0.0 ~ 5.0。
    var createdBy: Date? = null
):Parcelable
