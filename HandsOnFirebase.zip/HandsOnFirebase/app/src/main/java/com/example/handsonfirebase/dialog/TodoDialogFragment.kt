package com.example.handsonfirebase.dialog

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.RatingBar
import android.widget.Toast
import androidx.fragment.app.DialogFragment
import com.example.handsonfirebase.R
import com.example.handsonfirebase.model.Todo
import java.util.Date

private const val Todo = "todo"

// Todoデータ入力用ダイアログクラス
class TodoDialogFragment: DialogFragment() {
    
    private var todo: Todo? = null

    lateinit var memoEdit: EditText
    lateinit var priorityRating: RatingBar
    lateinit var submitButton: Button
    lateinit var cancelButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.getParcelable<Todo>(Todo)?.let {
            todo = it
        }
    }

    // 呼び出し元に実装してもらうリスナー
    internal lateinit var listener: TodoDialogListener
    interface TodoDialogListener {
        // 登録ボタンクリック処理
        fun onDialogSubmitClick(dialog: TodoDialogFragment, todo: Todo?)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.dialog_priority, container, false)

        memoEdit = view.findViewById(R.id.dMemoEdit)
        priorityRating = view.findViewById(R.id.dPriorityRating)
        submitButton = view.findViewById(R.id.submitButton)
        cancelButton = view.findViewById(R.id.cancelButton)

        todo?.let{
            memoEdit.setText(it.memo)
            priorityRating.rating = it.priority
        }

        submitButton.setOnClickListener {

            //　メモが空白の場合は処理を中断する
            if(memoEdit.text.isEmpty()){
                Toast.makeText(context, "メモを入力してください", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            todo?.let{
                it.memo = memoEdit.text.toString()
                it.priority = priorityRating.rating
                if(it.createdBy == null){
                    it.createdBy= Date()
                }
            }
            // 呼び出し元にダイアログの内容を渡す
            listener.onDialogSubmitClick(this, todo)

        }

        cancelButton.setOnClickListener {
            // キャンセル時は何もせずにダイアログを終了させる
            dismiss()
        }

        return view
    }

    override fun onResume() {
        super.onResume()
        // ダイアログを端末サイズに合わせてリサイズする
        dialog?.window?.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        try{
            listener = context as TodoDialogListener
        }catch (e: ClassCastException){
            throw ClassCastException((context.toString() + " must implement TodoDialogListener"))
        }
    }

    companion object {

        fun newInstance(todo: Todo?) =
            TodoDialogFragment().apply {
                arguments = Bundle().apply {
                    putParcelable(Todo, todo)
                }
            }
    }

}