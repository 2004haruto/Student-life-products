package com.example.handsonfirebase

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.firebase.ui.auth.AuthUI
import com.firebase.ui.auth.FirebaseAuthUIActivityResultContract
import com.firebase.ui.auth.data.model.FirebaseAuthUIAuthenticationResult
import com.google.firebase.auth.FirebaseAuth

class LoginActiviy : AppCompatActivity() {

    // FirebaseUI のランチャー設定
    private val signInLauncher = registerForActivityResult(
        FirebaseAuthUIActivityResultContract()
    ) { res ->
        this.onSignInResult(res)
    }

    // FirebaseUI処理後、呼び出されるメソッド
    private fun onSignInResult(result: FirebaseAuthUIAuthenticationResult) {
        if (result.resultCode == RESULT_OK) {
            // 認証ユーザ情報の取得
            val user = FirebaseAuth.getInstance().currentUser

            // 認証出来ていれば次の画面遷移する
            user?.let {
                val nextIntent = Intent(this, UserActivity::class.java)
                nextIntent.putExtra("userName", it.displayName)
                nextIntent.putExtra("email", it.email)
                startActivity(nextIntent)
            }
        } else {
            val response = result.idpResponse
            if (response == null) {
                Toast.makeText(
                    applicationContext, "認証がキャンセルされました",
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                response.error?.let {
                    Log.e("err", it.toString())
                }
            }
        }
    }

    // 認証プロバイダー設定
    val providers = arrayListOf(
        AuthUI.IdpConfig.GoogleBuilder().build(), // Google 認証追加
        AuthUI.IdpConfig.EmailBuilder().build()
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_login)

        // 既に認証済みの場合はスキップ
        val currentUser = FirebaseAuth.getInstance().currentUser
        if (currentUser != null) {
            val nextIntent = Intent(this, UserActivity::class.java)
            nextIntent.putExtra("userName", currentUser.displayName)
            nextIntent.putExtra("email", currentUser.email)
            startActivity(nextIntent)
            finish()
            return
        }

        val authButton: Button = findViewById(R.id.authButton)

        authButton.setOnClickListener {
            // サインインインテントをランチャーにセットしてFirebaseUIを起動
            val signInIntent = AuthUI.getInstance()
                .createSignInIntentBuilder()
                .setAvailableProviders(providers)
                .setLogo(R.mipmap.ic_launcher)
                .setTheme(R.style.Base_Theme_HandsOnFirebase)
                .build()
            signInLauncher.launch(signInIntent)
        }
    }
}
