package com.example.handsonfirebase

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.firebase.ui.auth.AuthUI
import com.google.firebase.auth.FirebaseAuth

class UserActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_user)

        // 前画面からユーザ情報を受け取る
        val myIntent = intent;
        val user = myIntent.getStringExtra("userName")
        val email = myIntent.getStringExtra("email")
        val userTv = findViewById<TextView>(R.id.userNameText)
        val emailTv = findViewById<TextView>(R.id.emailText)
        userTv.text = user
        emailTv.text = email

        val logoutButton = findViewById<Button>(R.id.userLogoutButton)
        val deleteButton = findViewById<Button>(R.id.userDeleteButton)
        val todoButton = findViewById<ImageView>(R.id.todoImage)

        logoutButton.setOnClickListener {
            // Firebase Authentication からログアウト
            AuthUI.getInstance().signOut(this)

            // ログイン画面に戻るためのインテントを作成
            val loginIntent = Intent(this, LoginActiviy::class.java)
            loginIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(loginIntent)

            // ユーザにログアウトを通知
            Toast.makeText(this, "ログアウトしました", Toast.LENGTH_SHORT).show()
        }

        deleteButton.setOnClickListener {
            AuthUI.getInstance().delete(this)
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        // アカウント削除成功時の処理
                        val loginIntent = Intent(this, LoginActiviy::class.java)
                        loginIntent.flags =
                            Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                        startActivity(loginIntent)

                        Toast.makeText(this, "アカウントが削除されました", Toast.LENGTH_SHORT)
                            .show()
                    } else {
                        // アカウント削除失敗時の処理
                        Toast.makeText(this, "アカウント削除に失敗しました", Toast.LENGTH_SHORT)
                            .show()
                    }
                }
        }

        todoButton.setOnClickListener {
            val todoIntent = Intent(this, MainActivity::class.java)
            startActivity(todoIntent)
        }
    }
}