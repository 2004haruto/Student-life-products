    package com.example.eccmemo

    import androidx.appcompat.app.AppCompatActivity
    import android.os.Bundle
    import android.util.Log
    import android.widget.Toast
    import androidx.recyclerview.widget.LinearLayoutManager
    import androidx.recyclerview.widget.RecyclerView
    import com.example.eccmemo.R
    import com.example.eccmemo.adapter.TodoAdapter
    import com.example.eccmemo.dialog.TodoDialogFragment
    import com.example.eccmemo.model.Todo
    import com.google.android.material.floatingactionbutton.FloatingActionButton
    import com.google.firebase.auth.FirebaseAuth
    import com.google.firebase.firestore.CollectionReference
    import com.google.firebase.firestore.Query
    import com.google.firebase.firestore.ktx.firestore
    import com.google.firebase.ktx.Firebase
    import java.util.Date

    class MainActivity : AppCompatActivity(), TodoDialogFragment.TodoDialogListener {

        lateinit var todoRecyclerView: RecyclerView
        lateinit var createFab: FloatingActionButton

        // Firestoreのコレクション参照変数を宣言
        lateinit var todoRef: CollectionReference

        // Firebase取得データ
        val todoList = mutableListOf<Todo>()

        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.activity_main)

            todoRecyclerView = findViewById(R.id.todoRecyclerView)
            createFab = findViewById(R.id.createButton)

            // Firestoreのコレクション参照をインスタンス化する
            todoRef = Firebase.firestore.collection("todos")

            // 現在ログイン中のユーザーIDを取得
            val currentUserId = FirebaseAuth.getInstance().currentUser?.uid

            if (currentUserId != null) {
                // Firestoreクエリを使用して、現在のユーザーに関連するデータのみを取得する
                todoRef.whereEqualTo("userId", currentUserId)
                    .orderBy("priority", Query.Direction.DESCENDING)
                    .addSnapshotListener { value, error ->
                        if (error != null) {
                            // エラーが発生した場合の処理
                            Log.e("FirestoreError", "データ取得エラー: ${error.message}")
                            Toast.makeText(this, "データの取得に失敗しました: ${error.message}", Toast.LENGTH_SHORT).show()
                            return@addSnapshotListener
                        }

                        value?.let {
                            // FirestoreのデータをTodoリストに変換し、表示を更新する
                            val todos = it.toObjects(Todo::class.java)
                            todoList.clear()
                            todoList.addAll(todos)
                            todoRecyclerView.adapter?.let {
                                it.notifyDataSetChanged()
                            }
                        }
                    }
            } else {
                // ユーザーがログインしていない場合のエラーメッセージ
                Toast.makeText(this, "ユーザーがログインしていません", Toast.LENGTH_SHORT).show()
            }

            todoRecyclerView.layoutManager = LinearLayoutManager(this)
            todoRecyclerView.adapter = TodoAdapter(
                todoList,
                cardOnClick = { todo ->
                    // カードをクリックされたら対象データのダイアログを表示
                    val newDialog = TodoDialogFragment.newInstance(todo)
                    newDialog.show(supportFragmentManager, "update")
                },
                deleteOnClick = { todo ->
                    // ゴミ箱アイコンクリックでTodoデータを削除
                    todoRef.document(todo.documentId!!).delete()
                    Toast.makeText(applicationContext, "${todo.memo}を削除しました", Toast.LENGTH_SHORT).show()
                }
            )

            createFab.setOnClickListener {
                // 新規Todoクラスを生成してダイアログを表示
                val newDialog = TodoDialogFragment.newInstance(Todo(userId = currentUserId))
                newDialog.show(supportFragmentManager, "create")
            }
        }

        // Todoダイアログの登録ボタンクリックイベント
        override fun onDialogSubmitClick(dialog: TodoDialogFragment, todo: Todo?) {
            todo?.let { todo ->
                if (todo.documentId == null) {
                    // DocumentIDが存在しない場合は、新規登録
                    todoRef.add(todo)
                } else {
                    // DocumentIDと一致するドキュメントを上書きする
                    todoRef.document(todo.documentId).set(todo)
                }
            }
            dialog.dismiss()
        }
    }
