package com.example.fragmentmenu

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView

class MenuFragment : Fragment() {
    private lateinit var menuImage: ImageView
    private lateinit var nextButton: Button

    // 画像リソースの配列
    private val imageResources = arrayOf(
        R.drawable.omeletrice,  // 最初の画像
        R.drawable.hamburg
    )

    // 現在の画像インデックス
    private var currentImageIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_menu, container, false)

        // UI要素の初期化
        menuImage = view.findViewById(R.id.menuImage)
        nextButton = view.findViewById(R.id.nextButton)

        // 最初の画像を設定
        menuImage.setImageResource(imageResources[currentImageIndex])

        // ボタンのクリックリスナーを設定
        nextButton.setOnClickListener {
            // インデックスを更新し、次の画像に切り替える
            currentImageIndex = (currentImageIndex + 1) % imageResources.size
            menuImage.setImageResource(imageResources[currentImageIndex])
        }

        return view
    }

    companion object {
        @JvmStatic
        fun newInstance() =
            MenuFragment().apply {
                arguments = Bundle().apply {
                }
            }
    }
}
