package com.example.handsonwebapi.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.example.handsonwebapi.R
import com.example.handsonwebapi.model.Weather

// class クラス名() はコンストラクタ
// クラスをインスタンス化するときに実行されるメソッド
// コンストラクタでは初期化をする
// : 継承 javaでいうextends
class WeatherAdapter(private val weatherList: List<Weather>, private val onClick:(Weather) -> Unit) : RecyclerView.Adapter<WeatherAdapter.ViewHolder>() {

    // レイアウトをどのような見た目にするかを定義する
    // 内部クラス　クラスの中にあるクラス
    class ViewHolder(item: View) : RecyclerView.ViewHolder(item) {
        val cardView : CardView
        val cityNameLabel : TextView
        val wetherLavel : TextView
        val temperatureLabel: TextView

        init {
            cardView = item.findViewById(R.id.weatherCard)
            cityNameLabel = item.findViewById(R.id.cityNameLabel)
            wetherLavel = item.findViewById(R.id.weatherLabel)
            temperatureLabel = item.findViewById(R.id.temperatureLabel)
        }

    }

    // ViewHolderをインスタンス化。見える形にする
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): WeatherAdapter.ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.weather_item, parent, false)
        return ViewHolder(view)
    }

    // ViewHolderの中身を入れていく。
    override fun onBindViewHolder(holder: WeatherAdapter.ViewHolder, position: Int) {
        holder.cityNameLabel.text = weatherList[position].name

        // 天気情報を表示
        holder.wetherLavel.text = weatherList[position].weather[0].description

        // 温度をケルビンから摂氏に変換し、「℃」を追加して表示
        val temperatureCelsius = weatherList[position].main.temp - 273.15
        holder.temperatureLabel.text = String.format("%.1f°C", temperatureCelsius)
        holder.cardView.setOnClickListener{
            onClick(weatherList[position])
        }
    }

    override fun getItemCount(): Int {
        return weatherList.size
    }

}
