package com.example.handsonwebapi

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.example.handsonwebapi.model.Weather

private const val ARG_PARAM1 = "param1"

/**
 * A simple [Fragment] subclass.
 * Use the [WeatherDetailsFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class WeatherDetailsFragment : Fragment() {
    // StringからWeatherに変更
    private var param1: Weather? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // パーセラブルのデータの代入
        arguments?.getParcelable<Weather>(ARG_PARAM1)?.let {
            weather -> param1 = weather
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_weather_details, container, false)

        // 各TextViewをレイアウトファイルから取得
        val cityName: TextView = view.findViewById(R.id.cityName_detail)
        val weather: TextView = view.findViewById(R.id.weather_detail)
        val feelsLike: TextView = view.findViewById(R.id.feelsLike_detail)
        val minTemp: TextView = view.findViewById(R.id.minTemp_detail)
        val maxTemp: TextView = view.findViewById(R.id.maxTemp_detail)
        val pressure: TextView = view.findViewById(R.id.pressure_detail)
        val humidity: TextView = view.findViewById(R.id.humidity_detail)
        val windSpeed: TextView = view.findViewById(R.id.windSpeed_detail)
        val clouds: TextView = view.findViewById(R.id.clouds_detail)
        val country: TextView = view.findViewById(R.id.country_detail)

        // param1にデータが存在していたら、テキストに都市名を代入
        // letで書いたら　?.の前の値は{}では[it]になる　param1→itに代わる
        param1?.let {
            cityName.text = it.name
            weather.text = "天気: ${it.weather[0].description}"
            feelsLike.text = String.format("体感温度: %.1f°C", it.main.feels_like - 273.15)
            minTemp.text = String.format("最低気温: %.1f°C", it.main.temp_min - 273.15)
            maxTemp.text = String.format("最高気温: %.1f°C", it.main.temp_max - 273.15)
            pressure.text = "気圧: ${it.main.pressure} hPa"
            humidity.text = "湿度: ${it.main.humidity}%"
            windSpeed.text = String.format("風速: %.1f m/s", it.wind.speed)
            clouds.text = "雲の割合: ${it.clouds.all}%"
            country.text = "国: ${it.sys.country}"        }

        return view
    }

    companion object {

        // 引数をString(都市名)からweather(1つの都市の天気情報全体)
        @JvmStatic
        fun newInstance(param1: Weather) =
            WeatherDetailsFragment().apply {
                arguments = Bundle().apply {
                    // putStringからputParcelableに変更
                    putParcelable(ARG_PARAM1, param1)
                }
            }
    }
}