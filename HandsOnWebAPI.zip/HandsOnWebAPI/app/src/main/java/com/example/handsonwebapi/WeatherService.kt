package com.example.handsonwebapi

import com.example.handsonwebapi.model.Weather
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface WeatherService {
    @GET("data/2.5/weather")
    fun fetchData(
        @Query("q") city: String,
        @Query("lang") lang: String,
        @Query("appid") apiKey: String
    ): Call<Weather>

}

