package com.example.animalpicturebook;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    Intent intent;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnDog = findViewById(R.id.btn_dog);
        Button btnLion = findViewById(R.id.btn_lion);
        Button btnCat = findViewById(R.id.btn_cat);
        Button btnCow = findViewById(R.id.btn_cow);
        Button btnElephant = findViewById(R.id.btn_elephant);

        ImageView iv_dog = findViewById(R.id.iv_dog);
        ImageView iv_lion = findViewById(R.id.iv_lion);
        ImageView iv_cat = findViewById(R.id.iv_cat);
        ImageView iv_cow = findViewById(R.id.iv_cow);
        ImageView iv_elephant = findViewById(R.id.iv_elephant);

        btnDog.setOnClickListener(v -> {
            intent = new Intent(this/*this->MainActivity*/, Explanation.class);
            intent.putExtra("count",0);
            startActivity(intent);
        });

        btnLion.setOnClickListener(v -> {
            intent = new Intent(this/*this->MainActivity*/, Explanation.class);
            intent.putExtra("count",1);
            startActivity(intent);
        });

        btnCat.setOnClickListener(v -> {
            intent = new Intent(this/*this->MainActivity*/, Explanation.class);
            intent.putExtra("count",2);
            startActivity(intent);
        });

        btnCow.setOnClickListener(v -> {
            intent = new Intent(this/*this->MainActivity*/, Explanation.class);
            intent.putExtra("count",3);
            startActivity(intent);
        });

        btnElephant.setOnClickListener(v -> {
            intent = new Intent(this/*this->MainActivity*/, Explanation.class);
            intent.putExtra("count",4);
            startActivity(intent);
        });

        iv_dog.setOnClickListener(view -> {
            playSound(R.raw.dog);
        });


        iv_lion.setOnClickListener(view -> {
            playSound(R.raw.lion);
        });

        iv_cat.setOnClickListener(view -> {
            playSound(R.raw.cat);
        });

        iv_cow.setOnClickListener(view -> {
            playSound(R.raw.cow);
        });

        iv_elephant.setOnClickListener(view -> {
            playSound(R.raw.elephant);
        });


    }

    private void playSound(int soundResourceId) {
        // mediaPlayer のインスタンスを生成
        MediaPlayer mediaPlayer = MediaPlayer.create(this, soundResourceId);
        // 指定された音源を再生
        mediaPlayer.start();
        // 音が再生完了したら、その音のリソースを解放する。
        mediaPlayer.setOnCompletionListener(MediaPlayer::release);
    }

}