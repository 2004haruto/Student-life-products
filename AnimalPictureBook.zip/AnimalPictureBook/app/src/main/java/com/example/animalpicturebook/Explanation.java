package com.example.animalpicturebook;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Explanation extends AppCompatActivity {

    final int [] IMAGES = {R.drawable.inu,R.drawable.laion,R.drawable.neko,R.drawable.usi,R.drawable.zou};
    final String [] EXPLANATION = {"犬は哺乳類である","ライオンは哺乳綱 食肉目 ネコ科 ヒョウ属 に分類される 食肉類。","猫は、リビアヤマネコが家畜化されたイエネコに対する通称である。","ウシ（牛）は、哺乳綱鯨偶蹄目ウシ科ウシ亜科の動物である。","ゾウはゾウ科に属する 哺乳類 の総称である。"};


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.kaisetsu);

        ImageView iv_animal = findViewById(R.id.iv_animal);;
        TextView tv_explanation = findViewById(R.id.tv_explanation);;

        Intent intent = getIntent();

        int count = intent.getIntExtra("count",0);

        iv_animal.setImageResource(IMAGES[count]);

        switch (count){
            case 0:
                tv_explanation.setText(EXPLANATION[count]);
                iv_animal.setOnClickListener(v -> {
                    playSound(R.raw.dog);
                });
                break;
            case 1:
                tv_explanation.setText(EXPLANATION[count]);
                iv_animal.setOnClickListener(v -> {
                    playSound(R.raw.lion);
                });
                break;
            case 2:
                tv_explanation.setText(EXPLANATION[count]);
                iv_animal.setOnClickListener(v -> {
                    playSound(R.raw.cat);
                });
                break;
            case 3:
                tv_explanation.setText(EXPLANATION[count]);
                iv_animal.setOnClickListener(v -> {
                    playSound(R.raw.cow);
                });
                break;
            case 4:
                tv_explanation.setText(EXPLANATION[count]);
                iv_animal.setOnClickListener(v -> {
                    playSound(R.raw.elephant);
                });
                break;

        }

    }

    private void playSound(int soundResourceId) {
        // mediaPlayer のインスタンスを生成
        MediaPlayer mediaPlayer = MediaPlayer.create(this, soundResourceId);
        // 指定された音源を再生
        mediaPlayer.start();
        // 音が再生完了したら、その音のリソースを解放する。
        mediaPlayer.setOnCompletionListener(MediaPlayer::release);
    }

}

