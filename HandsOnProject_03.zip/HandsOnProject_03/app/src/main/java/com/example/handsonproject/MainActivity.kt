package com.example.handsonproject

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    lateinit var srv: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // レイアウトとプログラムの紐づけ
        srv = findViewById(R.id.sampleRecyclerView)

        // レイアウトを設定（2列）
        srv.layoutManager = GridLayoutManager(applicationContext, 2)

        // デモ用の食べ物データを作成
        val foods = listOf(
            Food(R.drawable.apple, "apple", "果物"),
            Food(R.drawable.banana, "banana", "果物"),
            Food(R.drawable.cherry, "cherry", "果物"),
            Food(R.drawable.donut, "donut", "お菓子"),
            Food(R.drawable.egg, "egg", "食材"),
            Food(R.drawable.frenchfries, "frenchfries", "料理"),
            Food(R.drawable.grape, "grape", "果物"),
            Food(R.drawable.hamburger, "hamburger", "料理")
        )

        // RecyclerViewにAdapterをセット
        srv.adapter = FoodAdapter(foods) { food ->
            Toast.makeText(this, "選択された食べ物: ${food.name}", Toast.LENGTH_SHORT).show()  // 食べ物の名前を表示
        }
    }
}
