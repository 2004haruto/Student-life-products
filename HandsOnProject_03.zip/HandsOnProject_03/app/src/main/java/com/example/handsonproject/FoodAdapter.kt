package com.example.handsonproject

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView

class FoodAdapter(private val foods: List<Food>, private val onClick: (Food) -> Unit) : RecyclerView.Adapter<FoodAdapter.ViewHolder>() {

    class ViewHolder(item: View) : RecyclerView.ViewHolder(item) {
        val foodImageView: ImageView = item.findViewById(R.id.foodImageView)
        val nameLabel: TextView = item.findViewById(R.id.nameLabel)
        val categoryLabel: TextView = item.findViewById(R.id.categoryLabel)

        fun bind(food: Food, onClick: (Food) -> Unit) {
            foodImageView.setImageResource(food.imgResID)
            nameLabel.text = food.name
            categoryLabel.text = food.category

            // クリックリスナーを設定
            itemView.setOnClickListener { onClick(food) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.list_row, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(foods[position], onClick)  // データとクリックリスナーをバインド
    }

    override fun getItemCount(): Int {
        return foods.size
    }
}
