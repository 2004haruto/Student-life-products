package com.example.pianoplayer;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    private final int[] ivIds = {R.id.iv_do5_key,R.id.iv_do5s_key,R.id.iv_re5_key,R.id.iv_re5s_key,R.id.iv_mi5_key,R.id.iv_fa5_key,R.id.iv_fa5s_key,R.id.iv_so5_key,R.id.iv_so5s_key,R.id.iv_ra5_key,R.id.iv_ra5s_key,R.id.iv_si5_key,R.id.iv_do6_key};
    private final int[] soundFiles = {R.raw.do5,R.raw.do5s,R.raw.re5,R.raw.re5s,R.raw.mi5,R.raw.fa5,R.raw.fa5s,R.raw.so5,R.raw.so5s,R.raw.ra5,R.raw.ra5s,R.raw.si5,R.raw.do6};
    // ラーメンの画像を押したときのメロディの音階リスト
    private int[] melodys ={R.raw.so5,R.raw.mi5,R.raw.mi5,R.raw.fa5,R.raw.mi5,R.raw.re5,R.raw.do5,R.raw.so5,R.raw.mi5,R.raw.mi5,R.raw.re5,R.raw.mi5,R.raw.so5,R.raw.so5,R.raw.ra5,R.raw.ra5,R.raw.ra5,R.raw.do6,R.raw.mi5,R.raw.so5,R.raw.so5,R.raw.so5,R.raw.mi5,R.raw.mi5,R.raw.fa5,R.raw.mi5,R.raw.re5,R.raw.do5,R.raw.so5,R.raw.mi5,R.raw.mi5,R.raw.re5,R.raw.so5,R.raw.mi5,R.raw.ra5,R.raw.so5,R.raw.so5,R.raw.ra5,R.raw.ra5,R.raw.si5,R.raw.si5,R.raw.do6};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.piano);
        // レイアウトとの関連付け
        for (int i=0;i<ivIds.length;i++){
            ImageView ivMelody = findViewById(ivIds[i]);
            int index = i;
            ivMelody.setOnClickListener(v->{
                playSound(soundFiles[index]);
            });
        }

        Button btn_auto = findViewById(R.id.btn_auto_melody);
        btn_auto.setOnClickListener(v->{
            try {
                for (int i = 0;i < melodys.length;i++){
                    playSound(melodys[i]);
                    Thread.sleep(300);
                }
            }catch (InterruptedException e){
                throw new RuntimeException(e);
            }
        });
    }
    // 指定された音源 ID を使って音を再生するメソッド。
    private void playSound(int soundResourceId) {
        // mediaPlayer のインスタンスを生成
        MediaPlayer mediaPlayer = MediaPlayer.create(this, soundResourceId);
        // 指定された音源を再生
        mediaPlayer.start();
        // 音が再生完了したら、その音のリソースを解放する。
        mediaPlayer.setOnCompletionListener(MediaPlayer::release);
    }
}