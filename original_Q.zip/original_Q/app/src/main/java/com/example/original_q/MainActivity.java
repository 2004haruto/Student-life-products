package com.example.original_q;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;


public class MainActivity extends AppCompatActivity {

    final static int ID_IPHONE = 0;//IPhone
    final static int ID_ANDROID = 1;//Android

    //解答のID
    final int[] ANSWERS = {ID_IPHONE,ID_ANDROID,ID_ANDROID};

    //出題画像のID
    final int[] IMAGES = {R.drawable.iphone,R.drawable.android_phone_1,R.drawable.android_phpne_2};
    int count = 0;//正解数カウンタ
    int index = 0;//何問目かを保持するカウンタ
    ImageView ivQuestion;//クイズの出題画像


    ImageView questionImage;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_game);//メインゲーム画面表示

        //ボタンの定義&関連付け
        Button btnCabbage = findViewById(R.id.btn_IPhone);
        Button btnLettuce = findViewById(R.id.btn_Android);

        //キャベツボタンが押された際に呼び出される
        btnCabbage.setOnClickListener(view -> {
            checkAnswer(ID_IPHONE);
        });

        //レタスボタンが押された際に呼び出される
        btnLettuce.setOnClickListener(view -> {
            checkAnswer(ID_ANDROID);
        });

        //イメージビューの関連付け
        ivQuestion = findViewById(R.id.iv_question);
        //1問目のクイズの画像を表示
        ivQuestion.setImageResource(IMAGES[index]);
    }

    /**クイズの正解判定
     * @param selectId　キャベツ(0)かレタス(1)か判定するID
     */

    private  void checkAnswer(int selectId){
        //選択したIDが解答のIDと一致していた場合
        if (selectId == ANSWERS[index]) count++;//正解数加算
        index++;//次の問へ

        //まだ問題が残っていれば
        if (index < ANSWERS.length) {
            //次の問の画像表示
            ivQuestion.setImageResource(IMAGES[index]);
        }else{
            //最終問題に辿り着いていれば、結果画面に正解数を引き渡して遷移
            Intent intent = new Intent(this,ResultAcitity.class);
            intent.putExtra("count",count);
            startActivity(intent);//画面遷移
        }
    }
}
