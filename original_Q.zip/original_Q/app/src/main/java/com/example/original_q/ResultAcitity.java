package com.example.original_q;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class ResultAcitity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result_acitity);//結果画面表示

        //MainActivityから送信されたIntent情報を取得
        Intent intent = getIntent();

        //Intent情報から正解数のデータを取得
        int count = intent.getIntExtra("count",0);//正解数

        //正解数テキストビュー宣言＆関連付け
        TextView tvCount = findViewById(R.id.tv_count);
        //正解数をString型に変換し、テキストビューに表示
        tvCount.setText(String.valueOf(count));
    }
}