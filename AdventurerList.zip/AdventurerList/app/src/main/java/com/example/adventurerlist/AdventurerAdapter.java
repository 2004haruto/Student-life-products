package com.example.adventurerlist;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

//「冒険者」のデータを表示するためのアダプタークラス
public class AdventurerAdapter extends RecyclerView.Adapter<AdventurerAdapter.AdventurerViewHolder>{

    //冒険者のリストを保存する変数
    private List<Adventurer> adventurerList;

    //AdventurerAdapterのコンストラクタ:外部からアダプターを作成するときに使われる
    public AdventurerAdapter(Context context,List<Adventurer> adventurerList){
        //引数で受け取った冒険者リストを変数にセット
        this.adventurerList = adventurerList;
    }

    //新しいViewHolderを作成するメソッド
    @NonNull
    @Override
    public AdventurerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //冒険者のアイテムのレイアウトを読み込む
        View itemView =
                LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.adventurer_item_grid,parent,false);
        //新しいViewHolderを作成して返す
        return new AdventurerViewHolder(itemView);
    }

    //ViewHolderにデータを関連付けるメソッド
    @Override
    public void onBindViewHolder(@NonNull AdventurerViewHolder holder, int position) {
        //与えられた位置(position)にある冒険者データを取得
        Adventurer adventurer = adventurerList.get(position);

        //デバック用:取得した冒険者のデータをログに表示する
        Log.d("AdventurerAdapter","Loading data for adventurer at position" + position + ":" + adventurer.getName());
        Log.d("AdventurerAdapter","Loading data for adventurer at position" + position + ":" + adventurer.getLevel());
        Log.d("AdventurerAdapter","Loading data for adventurer at position" + position + ":" + adventurer.getJob());

        //取得した冒険者データを、ViewHolderの各部品に設定する
        holder.ivAdventurer.setImageResource(adventurer.getImgRes());
        holder.tvName.setText(adventurer.getName());
        holder.tvLevel.setText(String.valueOf(adventurer.getLevel()));//levelはint型なので、文字列に変換してtextに設定
        holder.tvJob.setText(adventurer.getJob());
    }

    @Override
    public int getItemCount() {
        return adventurerList.size();
    }

    public static class AdventurerViewHolder extends RecyclerView.ViewHolder{
        //変数定義
        ImageView ivAdventurer;
        TextView tvName,tvLevel,tvJob;

        //コンストラクタ
        public AdventurerViewHolder(@NonNull View itemView) {
            super(itemView);
            //レイアウトとの関連付け
            ivAdventurer = itemView.findViewById(R.id.iv_adventurer);
            tvName = itemView.findViewById(R.id.tv_name);
            tvLevel = itemView.findViewById(R.id.tv_level);
            tvJob = itemView.findViewById(R.id.tv_job);
        }
    }
}