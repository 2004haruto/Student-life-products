package com.example.adventurerlist;

public class Adventurer {
    //以下は冒険者の属性(またはプロパティ)です
    private int imgRes; //この冒険者の画像を示すリソースID
    private String name; //冒険者の名前
    private int level; //冒険者のレベル
    private String job; //冒険者の職業

    /**
     * Adventurerクラスのコンストラクタ
     * 新しい冒険者オブジェクトを作成する時にこのコンストラクタを使います。
     *
     * @param imgRes 画像のリソースID
     * @param name 冒険者の名前
     * @param level 冒険者のレベル
     * @param job 冒険者の職業
     */

    public Adventurer(int imgRes,String name,int level,String job){
        this.imgRes = imgRes;
        this.name = name;
        this.level = level;
        this.job = job;
    }

    //以下はゲッターメソッドです。これらのメソッドを使って、冒険者の属性の値を取得できます。
    public int getImgRes() {return imgRes;}
    public String getName() {return name;}
    public int getLevel() {return level;}
    public String getJob() {return job;}

}
