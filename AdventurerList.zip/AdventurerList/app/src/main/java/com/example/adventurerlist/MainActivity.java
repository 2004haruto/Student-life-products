package com.example.adventurerlist;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;
import android.widget.Toolbar;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

/**
 * MainActivityは、冒険者のリストを表示するアクティビティです。
 */
public class MainActivity extends AppCompatActivity {

    //冒険者のリストを表示するためのRecyclerView
    private RecyclerView recyclerView;

    //RecyclerViewで使用するアダプター
    private AdventurerAdapter adapter;

    //冒険者の情報を保存するリスト
    private List<Adventurer> adventurerList = new ArrayList<>();

    /**
     * アクティビティが作成されるときに呼ばれるメソッド
     * ここでレイアウトの設定やリストの初期化など、初期の設定を行います。
     * @param savedInstanceState 以前のアクティビティの状態を保存する場合に使用
     */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //activity_main.xmlをこのアクティビティのレイアウトとして設定
        setContentView(R.layout.activity_main);

        //ツールバーを設定。ツールバーはアプリの上部に表示される部分。
        androidx.appcompat.widget.Toolbar toolbar = findViewById(R.id.toolbar); // この行を追加
        setSupportActionBar(toolbar);

        //ツールバーのタイトルを"冒険者リスト"に設定
        getSupportActionBar().setTitle("冒険者リスト");

        //冒険者のリストを初期化
        initList();

        //rv_adventurer_listというIDを持つRecyclerViewをレイアウトから取得
        recyclerView = findViewById(R.id.rv_adventurer_list);

        //RecyclerViewにLinearLayoutManagerを設定(縦方向のリスト表示)
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));

        //RecyclerViewのアダプターを設定。アダプターには冒険者のリストを渡す
        adapter = new AdventurerAdapter(this, adventurerList);
        recyclerView.setAdapter(adapter);
    }

    public void initList() {
        //一時的なリストを作成して、そこにAdventurerオブジェクトを追加
        List<Adventurer> tempAdventurers = Arrays.asList(
                new Adventurer(R.drawable.swordman, "Alan", 20, "swordman"),
                new Adventurer(R.drawable.wizard, "beck", 18, "wizard"),
                new Adventurer(R.drawable.monk, "Checy", 22, "monk")
        );

        //adventurerListに一時的なリストの内容をすべて追加
        adventurerList.addAll(tempAdventurers);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //オーバーフローメニューをインプレート
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        //メニューアイテムのIDに応じて動作を定義
        if (item.getItemId() == R.id.menu_add) {
            addRandomAdventurer();//冒険者の追加
            Toast.makeText(this, "addが選択されました", Toast.LENGTH_SHORT).show();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void addRandomAdventurer() {
        // 利用可能な画像、名前、レベル、職業のリスト
        int[] images = {R.drawable.swordman, R.drawable.wizard, R.drawable.monk};
        String[] names = {"David", "Elena", "Flea", "Gin", "Hegge"};
        int[] levels = {15, 19, 23, 25, 30};
        String[] jobs = {"swordman", "wizard", "monk", "archer", "priest"};
        // ランダムな値を取得するための Random インスタンスを作成
        Random random = new Random();
        // それぞれのリストからランダムな値を取得
        int randomImage = images[random.nextInt(images.length)];
        String randomName = names[random.nextInt(names.length)];
        int randomLevel = levels[random.nextInt(levels.length)];
        String randomJob = jobs[random.nextInt(jobs.length)];
        // ランダムな冒険者を作成
        Adventurer randomAdventurer = new Adventurer(randomImage, randomName, randomLevel, randomJob);
        // 作成したランダムな冒険者を adventurerList に追加
        adventurerList.add(randomAdventurer);
        //RecyclerViewのアダプターにデータが変更されたことを通知
        adapter.notifyDataSetChanged();
    }
}
