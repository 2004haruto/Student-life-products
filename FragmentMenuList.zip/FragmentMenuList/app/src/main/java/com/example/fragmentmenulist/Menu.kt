package com.example.fragmentmenulist

data class Menu(
    val name: String,
    val category: String,
    val description: String,
    val imgResId: Int
)
