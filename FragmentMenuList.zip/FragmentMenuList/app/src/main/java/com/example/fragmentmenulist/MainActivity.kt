package com.example.fragmentmenulist

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class   MainActivity : AppCompatActivity() {
    // Bundleはデータの保持や受け渡しの仕組みです。
    // intentは画面の遷移と通信をするのに対して、Bundleはデータの保持に適しています。
    // intentもデータを渡すことができますが、複雑なデータを渡すのには適していません。
    // intentには軽いデータを渡しましょう!
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // メニューフラグメントの作成インスタンスの生成
        val foodMenuFragment = FoodMenuFragment.newInstance()
        // フラグメント変更のためのトランザクションの開始 FragmentManagerはフラグメントの追加・削除・置き換えなどを管理します
        val transaction = supportFragmentManager.beginTransaction()
        // フラグメントを紐づけする
        transaction.replace(R.id.fragmentContainerView, foodMenuFragment)
        // バックスタックへの追加、これにより戻るボタンを押したときに戻ることができる。nullは特定の名前を付けない
        transaction.addToBackStack(null)
        // トランザクションを確定し、実際の変更を実行します
        transaction.commit()

    }
}