package com.example.fragmentmenulist

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment

class MenuDetailFragment : Fragment() {

    // メニューの詳細を受け取る変数
    private var menuName: String? = null
    private var menuCategory: String? = null
    private var menuDescription: String? = null
    private var menuImageResId: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            // 受け取った引数を設定
            menuName = it.getString(ARG_PARAM1)
            menuCategory = it.getString(ARG_PARAM2)
            menuDescription = it.getString(ARG_PARAM3)
            menuImageResId = it.getInt(ARG_PARAM4)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // フラグメントのレイアウトを膨らませる
        val view = inflater.inflate(R.layout.fragment_menu_detail, container, false)

        // レイアウトのビューに情報を設定
        val menuImageView: ImageView = view.findViewById(R.id.menuDetailImage)
        val menuNameTextView: TextView = view.findViewById(R.id.menuDetailName)
        val menuCategoryTextView: TextView = view.findViewById(R.id.menuDetailCategory)
        val menuDescriptionTextView: TextView = view.findViewById(R.id.menuDetailDescription)

        // メニュー詳細を表示
        menuImageView.setImageResource(menuImageResId)
        menuNameTextView.text = menuName
        menuCategoryTextView.text = menuCategory
        menuDescriptionTextView.text = menuDescription

        return view
    }

    companion object {
        // 引数を受け取ってフラグメントを作成するファクトリメソッド
        private const val ARG_PARAM1 = "param1"
        private const val ARG_PARAM2 = "param2"
        private const val ARG_PARAM3 = "param3"
        private const val ARG_PARAM4 = "param4"

        @JvmStatic
        fun newInstance(menuName: String, menuCategory: String, menuDescription: String, menuImageResId: Int) =
            MenuDetailFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, menuName)
                    putString(ARG_PARAM2, menuCategory)
                    putString(ARG_PARAM3, menuDescription)
                    putInt(ARG_PARAM4, menuImageResId)
                }
            }
    }
}
