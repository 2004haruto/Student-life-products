package com.example.fragmentmenulist

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class FoodMenuFragment : Fragment() {

    val menu = listOf(    // 各メニューアイテムには、名前、カテゴリ、説明、画像リソースIDが含まれています。 // 以下はその例としていくつかのメニューアイテムを作成しています。
        Menu("ドリア", "メイン", "ふんわりとした白ご飯の上に、クリーミーなホワイトソースととろけるチーズをたっぷりと絡めました。オーブンで焼き上げることで、外はサクサク、中はもっちりとした食感に。", R.drawable.doria),
        Menu("チーズドリア", "メイン", "ドリアのクラシックな味わいに、3種類のチーズを贅沢に使用。濃厚なチーズが溶け出し、一口食べるたびに幸せな気分に。", R.drawable.doria),
        Menu("ガーデンサラダ", "サラダ", "新鮮な季節の野菜をふんだんに使用したサラダ。シャキシャキとした食感と、オリジナルドレッシングが相性抜群です。", R.drawable.sarada),
        Menu("ペコリーノチーズの温サラダ", "サラダ", "ペコリーノチーズの塩味と、温かい野菜の甘みが絶妙にマッチした一品。特製のドレッシングと一緒にどうぞ。", R.drawable.sarada),
        Menu("コーンスープ", "スープ", "コーンの甘みたっぷりのクリーミーなスープ。冷えた体を優しく温めます。", R.drawable.cornsoup),
        Menu("ハンバーグ", "メイン", "じっくりと煮込んだハンバーグは、外はしっかりと焼き上げられ、中はジューシー。特製のデミグラスソースでお楽しみください。", R.drawable.hamburg),
        Menu("エビグラタン", "メイン", "たっぷりのエビとクリーミーなホワイトソースを使ったグラタン。オーブンで焼き上げることで、香ばしさと濃厚さが一層増します。", R.drawable.guratan),
        Menu("マルゲリータピザ", "メイン", "シンプルながらも、トマト、モッツァレラチーズ、フレッシュバジルの3つの食材のハーモニーを楽しめるクラシックなピザ。", R.drawable.pizza)
    )

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Fragmentのレイアウトをinflateして表示する
        val view = inflater.inflate(R.layout.fragment_food_menu, container, false)

        // RecyclerViewの取得と設定
        val menuRV: RecyclerView = view.findViewById(R.id.menuRecyclerView)
        menuRV.layoutManager = GridLayoutManager(context, 2) // 2列のグリッドの作成

        // MenuAdapterの設定、アイテムクリックリスナーを設定
        menuRV.adapter = MenuAdapter(menu) { selectedMenu ->
            // アイテムクリック時にメニュー詳細をBundleでセット
            val bundle = Bundle().apply {
                // メニューの詳細情報をBundleに保存する
                putString("menuName", selectedMenu.name)
                putString("menuCategory", selectedMenu.category)
                putString("menuDescription", selectedMenu.description)
                putInt("menuImage", selectedMenu.imgResId)
            }

            // フラグメント間でデータを渡すためにsetFragmentResultを使用
            // "menuDetail"キーでデータを渡す
            parentFragmentManager.setFragmentResult("menuDetail", bundle)

            // クリック時にMenuDetailFragmentに遷移するためのコードを追加
            val detailFragment = MenuDetailFragment.newInstance(
                selectedMenu.name,
                selectedMenu.category,
                selectedMenu.description,
                selectedMenu.imgResId
            )

            // フラグメントトランザクションを開始し、MenuDetailFragmentに遷移
            parentFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainerView, detailFragment)  // フラグメントコンテナのIDを指定
                .addToBackStack(null)  // 戻るボタンで前のフラグメントに戻る
                .commit()
        }

        return view
    }

    // companion objectは静的メンバを定義する方法です。javaでいうstaticがついている状態
    // 静的メンバとはインスタンスと違い、newする必要がなく呼び出しができる。プログラム実行から終わりまでメモリに残る(複製ができない。)
    // なんでcompanion objectにするのか → 画面回転時などで情報が失われるから。
    // デザインパターンのFactory methodパターンが使われている。ざっくりというとインスタンス生成時にサブクラスで設定を行ってもらうような考え方。Factoryパターンもある。
    companion object {
        @JvmStatic
        fun newInstance() =
            FoodMenuFragment().apply {
                arguments = Bundle().apply {
                    // 必要に応じてBundleに情報をセットする
                }
            }
    }
}
