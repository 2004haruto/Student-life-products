package com.example.fragmentmenulist

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

// class クラス名() ()の箇所はコンストラクタにあたる
// -> Unitは戻りなし(Void)の関数であることを表す
// : は継承 javaのextendsと同じ意味
// <> はジェネリクス　型を作成時に指定を行う
class MenuAdapter(
    private val menus: List<Menu>,
    private val onItemClick: (Menu) -> Unit  // クリックリスナーの追加
) : RecyclerView.Adapter<MenuAdapter.ViewHolder>() {

    // ViewHolderはViewを参照するためのコンテナ、部品(View)をまとめている
    // ViewとはXMLで定義できるUI要素のこと Button, Text など
    // 別にクラスファイルを作るのではなく内部クラスにするのはどのViewHolderがどのAdapterと紐づいている
    // この方法はRecyclerViewのAdapterを作る際のベストプラクティスとされている
    class ViewHolder(item: View) : RecyclerView.ViewHolder(item) {
        val menuImageView: ImageView = item.findViewById(R.id.itemImg)  // 画像
        val menuName: TextView = item.findViewById(R.id.itemName)        // メニュー名
        val menuCategory: TextView = item.findViewById(R.id.itemCategory) // カテゴリ
    }

    // ここで上に書いた ViewHolder (ひとかたまりにした View) を生成している
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item, parent, false)
        return ViewHolder(view)
    }

    // リサイクラービューのデータ数がいくつあるかを返却する
    override fun getItemCount(): Int {
        return menus.size
    }

    // アイテムに対して、情報を紐づけるメソッド
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val menu = menus[position]
        // レイアウトにメニュー画像、メニュー名、メニューカテゴリを紐づけ
        holder.menuImageView.setImageResource(menu.imgResId)
        holder.menuName.text = menu.name
        holder.menuCategory.text = menu.category

        // アイテムがクリックされたときの動作
        holder.itemView.setOnClickListener {
            onItemClick(menu)  // クリックリスナーを呼び出し、クリックしたメニューアイテムのデータを渡す
        }
    }
}
