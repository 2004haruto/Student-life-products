package com.example.layoutsample;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {

    // 画面上で計算結果や数字を表示するための部分
    private TextView tvResult;
    // ユーザーが入力している途中の数字を保持
    private String currentInput = "";
    // ユーザーが選択した計算の種類（+や-など）を保持
    private String operation = "";
    // 計算の第一項となる数字を保持
    private String previousInput = "";

    // +,-,X,÷のボタンの動作を設定する部分
    private void setupOperationButtons() {
        // 4 つの計算ボタンの ID を配列で保持
        int[] operatorIds = {
                R.id.btn_plus, R.id.btn_minus, R.id.btn_multiplication, R.id.btn_division
        };
        for (int id : operatorIds) {
            Button btn = findViewById(id); // ボタンとコードを繋げる
            // この計算ボタンが押されたときの動作
            btn.setOnClickListener(v -> {
                if (!currentInput.isEmpty()) { // 数字が入力されている場合
                    previousInput = currentInput; // 入力された数字を第一項として保持
                    currentInput = ""; // 現在の入力をリセット
                    operation = ((Button) v).getText().toString(); // 選択された計算を保持
                }
            });
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.linearlayout_horizon);
        // 画面の計算結果表示部分とコードを繋げる
        tvResult = findViewById(R.id.tv_result);
        // 各ボタンの動作を設定
        setupNumberButtons(); // 数字ボタンの動作を設定
        setupOperationButtons(); // 計算のボタン（+や-など）の動作を設定
        setupEqualsButton(); // =ボタンの動作を設定
        setupResetButton(); // AC ボタンの動作を設定
    }

    // 0 から 9 までの数字ボタンの動作を設定する部分
    private void setupNumberButtons() {
        for (int i = 0; i < 10; i++) {
            // 画面のボタンとコードを繋げる
            int resID = getResources().getIdentifier("btn_" + i, "id", getPackageName());
            Button btn = findViewById(resID);
            // この数字ボタンが押されたときの動作
            btn.setOnClickListener(v -> {
                currentInput += ((Button) v).getText().toString(); // 押された数字を追加
                tvResult.setText(currentInput); // 画面に表示
            });
        }

    }
    // 実際に計算をする部分
    private double performOperation(double a, double b, String op) {
        switch (op) {
            case "+": return a + b; // 足し算
            case "-": return a - b; // 引き算
            case "X": return a * b; //乗算
            case "÷": return a / b; //除算
            default: return 0; // それ以外の場合は 0 を返す
        }
    }
    // =ボタンの動作を設定する部分
    private void setupEqualsButton() {
        Button btnEquals = findViewById(R.id.btn_equal); // =ボタンとコードを繋げる
        // =ボタンが押されたときの動作
        btnEquals.setOnClickListener(v -> {
            if (!previousInput.isEmpty() && !currentInput.isEmpty()
                    && !operation.isEmpty()) { // 第一項、第二項、計算の種類がすべて選択されている場合
                // 計算を実行
                double result = performOperation(Double.valueOf(previousInput),
                        Double.valueOf(currentInput), operation);
                tvResult.setText(String.valueOf(result)); // 画面に結果を表示
                currentInput = String.valueOf(result); // 結果を現在の入力として保持
                operation = ""; // 計算の種類をリセット
                previousInput = ""; // 第一項をリセット
            }
        });
    }
    // AC ボタンの動作を設定する部分
    private void setupResetButton() {
        Button btnReset = findViewById(R.id.btn_AC); // AC ボタンとコードを繋げる
        // AC ボタンが押されたときの動作
        btnReset.setOnClickListener(v -> {
            currentInput = ""; // 現在の入力をリセット
            previousInput = ""; // 第一項をリセット
            operation = ""; // 計算の種類をリセット
            tvResult.setText("0"); // 画面に 0 を表示
        });
    }
    private void setuphantenButton() {
        Button btnReset = findViewById(R.id.btn_change); // +/- ボタンとコードを繋げる
        // +/- ボタンが押されたときの動作
        btnReset.setOnClickListener(v -> {
            
        });
    }

}