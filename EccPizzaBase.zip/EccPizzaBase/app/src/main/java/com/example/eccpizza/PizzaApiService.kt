package com.example.eccpizza

import retrofit2.Call
import retrofit2.http.GET

const val BASE_URL = "api_balse_url"
interface PizzaApiService {
    @GET("xxxx.php")
    fun fetchAll():Call<List<Product>>
}