import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide
import com.example.eccpizza.Product
import com.example.eccpizza.R

class DetailFragment : Fragment() {
    private var product: Product? = null

    lateinit var productImage: ImageView
    lateinit var productNo: TextView
    lateinit var productName: TextView
    lateinit var category: TextView
    lateinit var price: TextView
    lateinit var detail: TextView

    // コンパニオンオブジェクト内に定義する
    companion object {
        private const val PRODUCT = "product"

        @JvmStatic
        fun newInstance(product: Product) =
            DetailFragment().apply {
                arguments = Bundle().apply {
                    putParcelable(PRODUCT, product)
                }
            }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.getParcelable<Product>(PRODUCT)?.let {
            product = it
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_detail, container, false)

        // Viewの初期化
        productImage = view.findViewById(R.id.itemImageView)
        productNo = view.findViewById(R.id.productNoText)
        productName = view.findViewById(R.id.productNameText)
        category = view.findViewById(R.id.categoryText)
        price = view.findViewById(R.id.priceText)
        detail = view.findViewById(R.id.detailText)

        // Productデータがあれば各ビューに値を設定
        product?.let { product ->
            // Glideで画像を表示
            Glide.with(this)
                .load(product.image_url)
                .into(productImage)

            // 各TextViewにProductのデータをセット
            productNo.text = product.product_no
            productName.text = product.pname
            category.text = product.category
            price.text = "￥${product.price}" // 全角￥マーク
            detail.text = product.detail
        }

        return view
    }
}
