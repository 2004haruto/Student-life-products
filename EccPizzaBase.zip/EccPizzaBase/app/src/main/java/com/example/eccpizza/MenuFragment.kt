package com.example.eccpizza

import MenuAdapter
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MenuFragment : Fragment() {

    // メニュー用リサイクラービュー
    lateinit var menuRV: RecyclerView

    // APIから取得した商品一覧を格納するリスト
    var productList = mutableListOf<Product>()

    // APIベースURL (BASE_URLの変数定義)
    private val BASE_URL = "https://click.ecc.ac.jp/ecc/yishida/pizzaDB.php/"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Retrofitのオブジェクトを生成
        val retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL) // ここにAPIの基本URLを設定
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        // APIとのやり取りを行うサービスを作成
        val api = retrofit.create(PizzaApiService::class.java)

        // APIから商品一覧を非同期で取得
        api.fetchAll().enqueue(object : Callback<List<Product>> {
            // APIとのアクセスが正常に完了したときに呼ばれるメソッド
            override fun onResponse(call: Call<List<Product>>, response: Response<List<Product>>) {
                // 商品一覧のリストを置き換える
                response.body()?.let { list ->
                    productList.clear() // リストをクリア
                    productList.addAll(list) // 新しい商品リストを追加

                    // メニューアダプターに新しいデータを通知してリサイクラーを更新
                    menuRV.adapter?.notifyDataSetChanged()
                }
            }

            // APIとのアクセスが異常に完了したときに呼ばれるメソッド
            override fun onFailure(call: Call<List<Product>>, t: Throwable) {
                // エラーハンドリング（今回は何もしない）
            }
        })
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // フラグメントのビューをインフレート
        val view = inflater.inflate(R.layout.fragment_menu, container, false)

        // RecyclerViewの設定
        menuRV = view.findViewById(R.id.menuRecyclerView)
        menuRV.layoutManager = GridLayoutManager(context, 2) // グリッド形式で表示

        // メニューアダプターを生成
        menuRV.adapter = MenuAdapter(productList, onMenuClick = { product ->
            // メニューをクリックしたら詳細フラグメントに切り替える
            val detailFragment = DetailFragment.newInstance(product)
            requireActivity().supportFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainerView, detailFragment)
                .addToBackStack(null) // 戻るボタンで戻れるようにスタックに追加
                .commit()
        })

        return view
    }

    companion object {
        @JvmStatic
        fun newInstance() =
            MenuFragment().apply {
                // 必要なデータを引き渡す場合はこちらに追加
            }
    }
}
