import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.eccpizza.Product
import com.example.eccpizza.R

class MenuAdapter(private val productList: List<Product>, private val onMenuClick: (Product) -> Unit) : RecyclerView.Adapter<MenuAdapter.ViewHolder>() {

    class ViewHolder(item: View) : RecyclerView.ViewHolder(item) {

        val cardView: CardView = item.findViewById(R.id.menuCard)
        val menuImage: ImageView = item.findViewById(R.id.menuImageView)
        val nameLabel: TextView = item.findViewById(R.id.nameLabel)
        val priceLabel: TextView = item.findViewById(R.id.priceLabel)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.pizza_item, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return productList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val product = productList[position]

        // GlideでURLから取得した画像をmenuImageに格納する
        Glide.with(holder.menuImage.context)
            .load(product.image_url)
            .into(holder.menuImage)

        // 商品名と価格を表示
        holder.nameLabel.text = product.pname
        holder.priceLabel.text = "￥${product.price}" // 全角￥マークを使用

        // カードがクリックされたときの処理
        holder.cardView.setOnClickListener {
            onMenuClick(product)
        }
    }
}
