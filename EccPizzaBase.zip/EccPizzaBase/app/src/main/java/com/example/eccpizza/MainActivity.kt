package com.example.eccpizza

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.eccpizza.MenuFragment

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // メニューフラグメントを表示

        // メニューフラグメントの作成インスタンスの生成
        val menuFragment = MenuFragment.newInstance()
        // フラグメント変更のためのトランザクションの開始 FragmentManagerはフラグメントの追加・削除・置き換えなどを管理します
        val transaction = supportFragmentManager.beginTransaction()
        // フラグメントを紐づけする
        transaction.replace(R.id.fragmentContainerView, menuFragment)
        // バックスタックへの追加、これにより戻るボタンを押したときに戻ることができる。nullは特定の名前を付けない
        transaction.addToBackStack(null)
        // トランザクションを確定し、実際の変更を実行します
        transaction.commit()
    }
}

