package com.example.handsonproject

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Food(
    val imgResID : Int,   //画像リソースID
    val name : String,    //食べ物の名前
    val category : String //カテゴリ
) : Parcelable
