package com.example.handsonproject

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class FoodAdapter(private val foods:List<Food>, private val onFoodClick:(Food) -> Unit) : RecyclerView.Adapter<FoodAdapter.ViewHolder>() {

    class ViewHolder(item: View) : RecyclerView.ViewHolder(item) {
        val foodItemView : ImageView
        val nameLabel : TextView
        val categoryLabel : TextView

        init {
            foodItemView = item.findViewById(R.id.foodImageView)
            nameLabel = item.findViewById(R.id.nameLabel)
            categoryLabel = item.findViewById(R.id.categoryLabel)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FoodAdapter.ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.list_row, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: FoodAdapter.ViewHolder, position: Int) {
        holder.foodItemView.setImageResource(foods[position].imgResID)
        holder.nameLabel.text = foods[position].name
        holder.categoryLabel.text = foods[position].category
        //
        holder.foodItemView.setOnClickListener {
            onFoodClick(foods[position])
        }
    }

    override fun getItemCount(): Int {
        return foods.size
    }
}