package com.example.handsonwebapi

import com.example.handsonwebapi.model.Weather
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

// WebAPIのベースURL
const val BASE_URL = "https://api.openweathermap.org/"

interface WeatherService {

    // 指定した都市の天気情報を取得するAPI(GET通信)
    @GET("data/2.5/weather")
    fun fetchData(
        @Query("q") city: String,
        @Query("lang") lang: String,
        @Query("appid") apiKey: String
    ): Call<Weather>
}