package com.example.handsonwebapi.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.handsonwebapi.R

class WeatherAdapter(private val weatherList: List<String>, private val onClick:(String) -> Unit) : RecyclerView.Adapter<WeatherAdapter.ViewHolder>() {

    val icons =
        listOf("01d","02d","03d","04d","09d","10d","11d","13d","50d","01n","02n")


    class ViewHolder(item: View) : RecyclerView.ViewHolder(item) {

        val cardView : CardView
        val cityNameLabel : TextView
        val weatherIcon : ImageView // 画像のView

        init {
            cardView = item.findViewById(R.id.weatherCard)
            cityNameLabel = item.findViewById(R.id.cityNameLabel)
            weatherIcon = item.findViewById(R.id.weatherIcon)
        }

    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): WeatherAdapter.ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.weather_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: WeatherAdapter.ViewHolder, position: Int) {
        holder.cityNameLabel.text = weatherList[position]

        // iconの画像
        val iconURL = "https://openweathermap.org/img/wn/${icons[position]}@2x.png"
        Glide.with(holder.itemView).load(iconURL).into(holder.weatherIcon)

        holder.cardView.setOnClickListener{
            onClick(weatherList[position])
        }
    }

    override fun getItemCount(): Int {
        return weatherList.size
    }

}
